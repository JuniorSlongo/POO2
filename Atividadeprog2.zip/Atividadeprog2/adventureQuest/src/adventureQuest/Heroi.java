package adventureQuest;

public class Heroi extends Personagem{
	
	
	
	public Heroi(int vida, int dano, int nivel) {
        super(vida, dano, nivel);
    }

    @Override
    void atacar(Personagem alvo) {
        System.out.println("Heroi atacando o inimigo!");
        alvo.receberDano(getDano(), getNivel());
    }

    @Override
    void defender() {
        System.out.println("Heroi defendendo-se!");
    }

    void habilidadeEspecial() {
        System.out.println("Habilidade especial do heroi!");
    }
	
	
}
