package adventureQuest;

public class Monstro extends Personagem{
	
	
	public Monstro(int vida, int dano, int nivel) {
        super(vida, dano, nivel);
    }

    @Override
    void atacar(Personagem alvo) {
        System.out.println("Monstro atacando o herói!");
        alvo.receberDano(getDano(), getNivel());
    }

    @Override
    void defender() {
        System.out.println("Monstro defendendo-se!");
    }


}
