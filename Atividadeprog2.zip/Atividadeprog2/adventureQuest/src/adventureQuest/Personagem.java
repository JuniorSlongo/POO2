package adventureQuest;

public abstract class Personagem {
	private int vida;
    private int dano;
    private int nivel;

    public Personagem(int vida, int dano, int nivel) {
        this.vida = vida;
        this.dano = dano;
        this.nivel = nivel;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public int getDano() {
        return dano;
    }

    public void setDano(int dano) {
        this.dano = dano;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    abstract void atacar(Personagem alvo);

    abstract void defender();

    void receberDano(int dano, int nivelAtacante) {
        if (nivelAtacante < nivel) {
            System.out.println("O ataque foi reduzido devido ao nível do defensor.");
            dano -= 5; // Redução de 5 pontos de dano
            if (dano < 0) {
                dano = 0; // Garante que o dano não seja negativo
            }
        }
        vida -= dano;
        if (vida <= 0) {
            System.out.println("O personagem foi derrotado!");
        }
    }
}
