package adventureQuest;

public class Main {

	public static void main(String[] args) {
        // Criando instâncias de personagens
        Heroi heroi = new Heroi(100, 20, 5); // Nível 5
        Monstro monstro = new Monstro(80, 15, 3); // Nível 3

        // Interagindo entre os personagens
        heroi.atacar(monstro);
        monstro.atacar(heroi);
        heroi.atacar(monstro);
        monstro.atacar(heroi);
        heroi.atacar(monstro);
        monstro.atacar(heroi);
        heroi.atacar(monstro);

        // Verificando os atributos dos personagens após a interação
        System.out.println("Vida do heroi: " + heroi.getVida());
        System.out.println("Vida do monstro: " + monstro.getVida());
    }

}
