package adventureQuest;

public class Arma implements Coletavel{
	
	@Override
	public void usar() {
		System.out.println("Arma usada para atacar.");
	}
	
	@Override
	public void descartar() {
		System.out.println("Arma descartada.");
	}
	
	
}
