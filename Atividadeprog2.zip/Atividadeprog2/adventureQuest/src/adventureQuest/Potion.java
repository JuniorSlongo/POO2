package adventureQuest;

public class Potion implements Coletavel {
	@Override
	public void usar() {
		System.out.println("Poção usada para curar.");
	}
	
	@Override
	public void descartar() {
		System.out.println("Poção descartada.");
	}
}
