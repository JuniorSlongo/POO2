package adventureQuest;

public interface Coletavel {
	void usar();
	void descartar();
}
